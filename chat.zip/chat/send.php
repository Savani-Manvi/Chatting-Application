<?php

	include 'connection.php';

	session_start();

	if($_POST['type']==5){
		$sid=$_POST['sid'];
		$rid=$_POST['rid'];
		$message=$_POST['message'];

		$sql = "INSERT INTO message(sid, rid, message) VALUES ('$sid','$rid','$message')";
			if (mysqli_query($conn, $sql)){
				echo json_encode(array("statusCode"=>200));
				$id=$rid;
			} 
			else {
				echo json_encode(array("statusCode"=>201));
			}
		mysqli_close($conn);
	}
	
?>