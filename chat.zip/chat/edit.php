<?php

	include 'connection.php';
	include 'button.php';

?>

<html>
<head>
	<link href= 'https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>  
    <script src= "https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js" > </script>   
    <script src= "https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" > </script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<title></title>
	<style type="text/css">
		#div12 #div13{
			width: 40%;
		    float: right;
		    text-align: left;
    		font-size: 20px;
    		color: black;
		}
		#div12 #div13 h1{
			font-size: 40px;
    		font-weight: 500;
		}
		#div12 #div13 input[type="text"] {
            width: 90%;
            height: 30px;
            border-radius: 5px;
            padding-left: 10px;
            border: 1px solid #BDBDBD;
            font-size: 15px;
        }
        #div12 #div13 input[type="text"]:focus {
        	outline: none;
        }
        #div12 #div13 input[type=button] {
            width: 205px;
            height: 45px;
            text-align: center;
            font-size: 19px;
            margin-top: 10px;
            margin-bottom: 10px;
            font-family: 'Freight Sans Bold', helvetica, arial, sans-serif !important;
            font-weight: bold !important;
            background: linear-gradient(#67ae55, #578843);
            background-color: #69a74e;
            box-shadow: inset 0 1px 1px #a4e388;
            border-color: #3b6e22 #3b6e22 #2c5115;
            border: 1px solid;
            border-radius: 5px;
            color: #fff;
            cursor: pointer;
            display: inline-block;
            position: relative;
            text-shadow: 0 1px 2px rgba(0,0,0,.5);
        }
	</style>
</head>
<body>
	<div class="alert alert-success alert-dismissible" id="success" style="display:none;">
	  <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	</div>

	<div class="alert alert-danger alert-dismissible" id="error" style="display:none;">
	  <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	</div>
	<br>
	
<?php

	$email=$_SESSION['email'];
	$query=mysqli_query($conn,"SELECT * FROM login where email='$email'")or die(mysqli_error());
	$row=mysqli_fetch_array($query);
  	$fname=$row['fname'];
	$lname=$row['lname'];
	$gender=$row['gender'];
	$dob=implode("/", array_reverse(explode('-', $row['dob'])));
	$email=$row['email'];

?>

	<div id="div12">
        <div id="div13">
        	<h1>Edit User Detail</h1>
            Name<br>
            <input type="text" class="form-control" id="fname" name="fname" value="<?php echo $fname; ?>"><br>
			<input type="text" class="form-control" id="lname" name="lname" value="<?php echo $lname; ?>">
			<br><br>
            Gender<br>
			<input type="radio" class="form-control" id="gender" name="gender" value="Male"<?php if($gender == 'Male'){echo 'checked';} ?>>Male
			<input type="radio" class="form-control" id="gender" name="gender" value="Female"<?php if($gender == 'Female'){echo 'checked';} ?>>Female
			<br><br>
            Date of Birth<br>
           	<input type="text" class="form-control" id="dob" name="dob" value="<?php echo $dob; ?>">
           	<br><br>
            Email<br>
			<input type="text" class="form-control" id="email" name="email" value="<?php echo $email; ?>">
			<br><br>
			<input type="button" name="edit" class="btn btn-primary" value="Save" id="butedit">
        </div>
    </div>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" ></script>
<script type="text/javascript">
	$(document).ready(function(){

		$(function() {
            $('#dob').datepicker({
           		dateFormat: "dd/mm/yy"
            });
        });

		$('#butedit').on('click', function(){
			$("#butedit").attr("disabled", "disabled");
			var fname = $('#fname').val();
			var lname = $('#lname').val();
			var gender=$('input[type="radio"]:checked').val();
			var dob=$('#dob').val();
			var email = $('#email').val();
			if(fname!="" && lname!="" && gender!="" && dob!="" && email!=""){
				$.ajax({
					url: "update.php",
					type: "POST",
					data: {
						type: 3,
						'fname': fname,
						'lname': lname,
						'gender': gender,
						'dob': dob,
						'email': email						
					},
					cache: false,
					success: function(dataResult){
						var dataResult = JSON.parse(dataResult);
						console.log(dataResult);
						if(dataResult.statusCode==200){
							location.href = "profile.php";						
						}
						else if(dataResult.statusCode==201){
							$("#error").show();
							$('#error').html('');
							alert('Email ID already exists!');
						}
					}
				});
			}
			else{
				alert('Please fill all the field!');
			}
		});

	});
</script>
</body>
</html>