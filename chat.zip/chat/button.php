<?php

	include "connection.php";

	session_start();

	$sql=mysqli_query($conn, "SELECT * FROM login WHERE email='$_SESSION[email]'");
	$row=mysqli_fetch_array($sql);
	
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style type="text/css">
		body {
		    width: 100%;
		    margin: 0 auto;
		    font-family: "lucida grande",tahoma,verdana,arial,sans-serif;
		}
		#div6 {
		    width: 100%;
		    min-width: 90%;
		    background-color: #4C66A4;
		}
		#div7 {
		    width: 80%;
		    margin: 0px auto;
		    height: 100px;
		}
		#div7 #div8{
			width: 50%;
			padding-top: 5px;
		}
		#div7 #div9 {
			text-align: end;
    		margin-top: -50px;
    		width: 35%;
    		float: right
		}
		#div7 #div8 h1 {
			margin: auto;
            color: white;
            text-align: left;
            font-size: 45px;
            position: relative;
            top: 18px;
            
        }
		#div7 #div9 h3{
			color: white;
		}
		#div7 #div9 button{
			height: 25px;
            background-color: #08298A;
            color: white;
            border: 1px solid #08298A;
		}
	</style>
</head>
<body>
	<div id="div6">
        <div id="div7">
        	<div id="div8"><h1>My Chat</h1></div>
        	<div id="div9">
            <h3>Welcome <?php echo $row['fname']; ?>&nbsp<?php echo $row['lname']; ?></h3>
        	<button><a href="profile.php" style="text-decoration: none; color: white;">Profile</a></button>
			<button><a href="changepass.php" style="text-decoration: none; color: white;">Change Password</a></button>
			<button><a href="chat.php" style="text-decoration: none; color: white;">Chat</a></button>
        </div>
    </div>
</body>
</html>