<?php

	include 'connection.php';
	include 'button.php';

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<style type="text/css">
		#div14 #div15{
			width: 40%;
		    float: right;
		    text-align: left;
    		font-size: 20px;
    		color: black;
		}
		#div14 #div15 h1{
			font-size: 40px;
    		font-weight: 500;
		}
		#div14 #div15 input[type="text"] {
            width: 90%;
            height: 30px;
            border-radius: 5px;
            padding-left: 10px;
            border: 1px solid #BDBDBD;
            font-size: 15px;
        }
        #div14 #div15 input[type="text"]:focus {
        	outline: none;
        }
        #div14 #div15 input[type=button] {
            width: 205px;
            height: 45px;
            text-align: center;
            font-size: 19px;
            margin-top: 10px;
            margin-bottom: 10px;
            font-family: 'Freight Sans Bold', helvetica, arial, sans-serif !important;
            font-weight: bold !important;
            background: linear-gradient(#67ae55, #578843);
            background-color: #69a74e;
            box-shadow: inset 0 1px 1px #a4e388;
            border-color: #3b6e22 #3b6e22 #2c5115;
            border: 1px solid;
            border-radius: 5px;
            color: #fff;
            cursor: pointer;
            display: inline-block;
            position: relative;
            text-shadow: 0 1px 2px rgba(0,0,0,.5);
        }
	</style>
</head>
<body>
	<div class="alert alert-success alert-dismissible" id="success" style="display:none;">
		<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	</div>

	<div class="alert alert-danger alert-dismissible" id="error" style="display:none;">
		<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	</div>

	<div id="div14">
        <div id="div15">
            <h1>Edit User Password</h1>
            Old Password<br>
            <input type="text" class="form-control" id="password" placeholder="Password" name="password">
            <br><br>
            Password<br>
            <input type="text" class="form-control" id="npassword" placeholder="New Password" name="npassword">
            <br><br>
            Re-enter New Password<br>
            <input type="text" class="form-control" id="cpassword" placeholder="Confirm Password" name="cpassword">
            <br><br>
            <input type="button" name="password" class="btn btn-primary" value="Change Password" id="butpass">
        </div>
    </div>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" ></script>
<script>
	$(document).ready(function(){

		$('#butpass').on('click', function(){
			$("#butpass").attr("disabled", "disabled");
			var password = $('#password').val();
			var npassword = $('#npassword').val();
			var cpassword =$('#cpassword').val();
			if(password!="" && npassword!="" && cpassword!=""){
				$.ajax({
					url: "password.php",
					type: "POST",
					data: {
						'password': password,
						'npassword': npassword,
						'cpassword': cpassword						
					},
					cache: false,
					success: function(dataResult){
						var dataResult = JSON.parse(dataResult);
						console.log(dataResult);
						if(dataResult.statusCode==201){
							$("#error").show();
							$('#error').html('');
							alert('Incorrect Password!');
						}
						else if(dataResult.statusCode==200){
							location.href = "profile.php";
						}
						else if(dataResult.statusCode==203){
							$("#error").show();
							$('#error').html('');
							alert('Check new password and re-enter password!');
						}
	
					}
				});
			}
			else{
				alert('Please fill all the field!');
			}
		});

	});
</script>
</body>
</html>