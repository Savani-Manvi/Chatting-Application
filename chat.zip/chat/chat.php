<?php

	include 'connection.php';
	include 'button.php';

	if(isset($_GET['id'])){
		$id=$_GET['id'];
	}

	$sql=mysqli_query($conn, "SELECT id FROM login WHERE email='$_SESSION[email]'");
	$row=mysqli_fetch_array($sql);

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<style type="text/css">
		#div18 {
			height: 100%;
        	background: #f2f2f2;
        	float: left;
			width: 23%;
		}
		#div19 {
		    margin: 0 auto;
		    padding: 0px;
		    width: 74%;
		    float: right;
    		margin-right: 20px;
		}
	    #div19 div {
	        float: left;
	        font-family: helvetica, arial, sans-serif;
	        padding-bottom: 20px;
	    }
	    #div19 #div20 {
	        margin-top: 30px;
	        width: 100%;
	        height: auto;
	        text-align: left;
	    }
        #div19 #div20 p {
            font-size: 15px;
            font-family: arial;
            margin: 0px;
            color: #0e385f;
            margin-bottom: 10px;
        }
        #div19 #div20 p span{
        	font-size: 8px;
        	display: block;
        }
        #div19 #div21{
	        margin-top: 30px;
	        width: 100%;
	        height: auto;
	        text-align: left;
	    }
	    #div19 #div21 input[type="text"]{
	    	width: 100%;
	    	height: 25px;
    		border: 1px solid #9d9696;
	    }
	    #div19 #div21 input[type="text"]:focus{
	    	outline:none;
	    }
	</style>
</head>
<body>
	<div class="alert alert-success alert-dismissible" id="success" style="display:none;">
	  <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	</div>

	<div class="alert alert-danger alert-dismissible" id="error" style="display:none;">
	  <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	</div>
	<div id="div17">
		<div id="div18">

<?php include "message.php"; ?>

		</div>
		<div id="div19">
	    	<div id="div20">

<?php

	//include "chat1.php";

?>
			</div>
	    	<div id="div21">
				<div class="form-group" align="bottom" style="display:none">
					<input type="text" class="form-control" id="sid" placeholder="" name="sid" value="<?php echo $row['id'] ?>">
				</div>
				<div class="form-group" align="bottom" style="display:none">
					<input type="text" class="form-control" id="rid" placeholder="" name="rid" value="<?php echo $id; ?>">
				</div>
				<div class="form-group" align="bottom" style="width: 100%;">
					<input type="text" class="form-control" id="message" placeholder="" name="message" onchange="send_message()" autofocus>
				</div>
	    	</div>
		</div>
	</div>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" ></script>
<script>

	function send_message(){
			var sid = $('#sid').val();
			var rid = $('#rid').val();
			var message = $('#message').val();
			if(message!=""){
				$.ajax({
					url: "send.php",
					type: "POST",
					data: {
						type: 5,
						'sid': sid,
						'rid': rid,
						'message': message						
					},
					cache: false,
					success: function(dataResult){
						$('#message').val('');
						var dataResult = JSON.parse(dataResult);
						if(dataResult.statusCode==200){ 
							$("#butsave").removeAttr("disabled");
							$('#register_form').find('input:text').val('');
							$.get("chat1.php?id=<?php echo $id; ?>", function(html) {
                    			$("#div1").html(html);
                			});
						}
						else if(dataResult.statusCode==201){
							$("#error").show();
							$('#error').html('');
							alert('Something went to wrong!');
						}
					}
				});
			}
			else{
				alert('Please fill all the message field!');
			}
		}

	$(document).ready(function(){

		setInterval(function () {
			$.get("chat1.php?id=<?php echo $id; ?>", function(html) {
                $("#div20").html(html);
            });
		}, 1000);

	});
</script>

</body>
</html>