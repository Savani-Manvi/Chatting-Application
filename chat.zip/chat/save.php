<?php

	include 'connection.php';
	
	session_start();

	if($_POST['type']==1){
		$fname=$_POST['fname'];
		$lname = $_POST['lname'];
		$gender = $_POST['gender'];
		$dob = implode("-", array_reverse(explode('/', $_POST['dob'])));
		$email=$_POST['email'];
		$password=$_POST['password'];
		
		$duplicate=mysqli_query($conn,"select * from login where email='$email'");
		if(mysqli_num_rows($duplicate)>0){
			echo json_encode(array("statusCode"=>201));
		}
		else{
			$sql = "INSERT INTO login(fname, lname, gender, dob, email, password) VALUES ('$fname','$lname','$gender','$dob','$email','$password')";
			if (mysqli_query($conn, $sql)){
				echo json_encode(array("statusCode"=>200));
			} 
			else {
				echo json_encode(array("statusCode"=>201));
			}
		}
		mysqli_close($conn);
	}

	if($_POST['type']==2){
		$email=$_POST['email'];
		$password=$_POST['password'];
		$check=mysqli_query($conn,"select * from login where email='$email' and password='$password'");
		if (mysqli_num_rows($check)>0){
			$_SESSION['email']=$email;
			echo json_encode(array("statusCode"=>200));
		}
		else{
			echo json_encode(array("statusCode"=>201));
		}
		mysqli_close($conn);
	}
	
?>