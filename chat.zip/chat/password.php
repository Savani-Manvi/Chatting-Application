<?php

    include'connection.php';

    session_start();

        $password=$_POST['password'];
        $npassword=$_POST['npassword'];
        $cpassword=$_POST['cpassword'];
        
        $sql = mysqli_query($conn, "SELECT password FROM login WHERE email='$_SESSION[email]'");
        $row=mysqli_fetch_array($sql);
        if($password !== $row['password']){
        	echo json_encode(array("statusCode"=>201));
       	}
        else{
        	if($npassword == $cpassword){
        		$query = "UPDATE login SET password='$npassword' WHERE password='$password'";
        		if (mysqli_query($conn, $query)){
                	echo json_encode(array("statusCode"=>200));
            	}
        	}
        	else{
        		echo json_encode(array("statusCode"=>203));
        	}
        }
        mysqli_close($conn);

?>