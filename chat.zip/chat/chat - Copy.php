<?php

	include 'connection.php';
	include 'button.php';

	session_start();

	if(isset($_GET['id'])){
		$id=$_GET['id'];
	}

?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
   	<link href='https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>
	<title></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<style type="text/css">
		#wrapper {
		    margin: 0 auto;
		    padding: 0px;
		    text-align: center;
		    width: 96%;
		}
	    #wrapper div {
	        float: left;
	        font-family: helvetica, arial, sans-serif;
	        padding-bottom: 20px;
	    }
	    #wrapper #div1 {
	        margin-top: 30px;
	        width: 100%;
	        height: auto;
	        text-align: left;
	    }
        #wrapper #div1 p {
            font-size: 20px;
            font-family: arial;
            margin: 0px;
            color: #0e385f;
            margin-bottom: 15px;
        }
        #wrapper #div1 p span{
        	font-size: 8px;
        	display: block;
        }
        #wrapper #div2{
	        margin-top: 30px;
	        width: 100%;
	        height: auto;
	        text-align: left;
	    }
	    #wrapper #div2 input[type="text"]{
	    	width: 100%;
	    }
	</style>
</head>
<body>
	<div class="alert alert-success alert-dismissible" id="success" style="display:none;">
	  <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	</div>

	<div class="alert alert-danger alert-dismissible" id="error" style="display:none;">
	  <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	</div>
	<div id="wrapper">
	    <div id="div1">
	    	
<?php

	$sql=mysqli_query($conn, "SELECT id FROM login WHERE email='$_SESSION[email]'");
	$row=mysqli_fetch_array($sql);

	$query="SELECT * FROM message WHERE (sid, rid) IN (VALUES ('$id', '$row[id]'), ('$row[id]', '$id')) ORDER BY id";
	$mess=$conn->query($query);
	if($mess->num_rows > 0){
		while($r=$mess->fetch_assoc()){
			if($r['sid'] == $id){
				echo "<p align = 'left'>".$r['message']."<span>".$r['time']."</span></p>";
			}
			else{
				echo "<p align = 'right'>".$r['message']."<span>".$r['time']."</span></p>";
			}			
		}
	}

	date_default_timezone_set('Asia/Kolkata');
	$time = date('h:i:s', time());

?>

		</div>
	    <div id="div2">
	    	<form id="register_form" name="form1" method="POST">
				<div class="form-group" align="bottom" style="display:none">
					<input type="text" class="form-control" id="sid" placeholder="" name="sid" value="<?php echo $row['id'] ?>">
				</div>
				<div class="form-group" align="bottom" style="display:none">
					<input type="text" class="form-control" id="rid" placeholder="" name="rid" value="<?php echo $id; ?>">
				</div>
				<div class="form-group" align="bottom" style="width: 100%;">
					<input type="text" class="form-control" id="message" placeholder="" name="message" autofocus>
					<input type="submit" name="send" class="btn btn-primary" value="Send" id="butsend" style="display: none">
				</div>
			</form>
	    </div>
	</div>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" ></script>
<script>
	$(document).ready(function(){

		$('#butsend').on('click', function(){
			var sid = $('#sid').val();
			var rid = $('#rid').val();
			var message = $('#message').val();
			if(message!=""){
				$.ajax({
					url: "send.php",
					type: "POST",
					data: {
						type: 5,
						'sid': sid,
						'rid': rid,
						'message': message						
					},
					cache: false,
					success: function(dataResult){
						var dataResult = JSON.parse(dataResult);
						if(dataResult.statusCode==200){ 
							$("#butsave").removeAttr("disabled");
							$('#register_form').find('input:text').val('');
						}
						else if(dataResult.statusCode==201){
							$("#error").show();
							$('#error').html('');
							alert('Something went to wrong!');
						}
					}
				});
			}
			else{
				alert('Please fill all the message field!');
			}
		});

	});
</script>
</body>
</html>