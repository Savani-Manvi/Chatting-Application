<?php

    include'connection.php';

    session_start();

    if($_POST['type']==3){
        $fname=$_POST['fname'];
        $lname = $_POST['lname'];
        $gender = $_POST['gender'];
        $dob = implode("-", array_reverse(explode('/', $_POST['dob'])));
        $email=$_POST['email'];
        
        $duplicate=mysqli_query($conn,"SELECT email FROM login WHERE email='$_SESSION[email]'");
        if((mysqli_num_rows($duplicate)>0) && ($email !== $_SESSION['email'])) {
            echo json_encode(array("statusCode"=>201));
        }
        else{
            $sql = "UPDATE login SET fname='$fname', lname='$lname', gender='$gender', dob='$dob', email='$email' WHERE email='$_SESSION[email]'";
            if (mysqli_query($conn, $sql)){
                echo json_encode(array("statusCode"=>200));
                $_SESSION['email']=$email;
            } 
            else {
                echo json_encode(array("statusCode"=>201));
            }
        }
        mysqli_close($conn);
    }
?>