<?php

	include 'connection.php';
	include 'button.php';

?>

<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="styles.css" />
	<style type="text/css">
		#div10 {
		    margin: 0 auto;
		    width: 90%;
		    background-color: white;
		    padding-left: 135px;
    		padding-top: 20px;
		}
		#div10 #div11 h1{
			font-size: 40px;
    		font-weight: 500;
		}
		#div10 #div11 h6{
			font-size: 20px;
    		font-weight: 100;
    		display: contents;
		}
		#div10 #div11 button {
            width: 205px;
            height: 45px;
            text-align: center;
            font-size: 19px;
            margin-top: 10px;
            margin-bottom: 10px;
            font-family: 'Freight Sans Bold', helvetica, arial, sans-serif !important;
            font-weight: bold !important;
            background: linear-gradient(#67ae55, #578843);
            background-color: #69a74e;
            box-shadow: inset 0 1px 1px #a4e388;
            border-color: #3b6e22 #3b6e22 #2c5115;
            border: 1px solid;
            border-radius: 5px;
            color: #fff;
            cursor: pointer;
            display: inline-block;
            position: relative;
            text-shadow: 0 1px 2px rgba(0,0,0,.5);
        }
	</style>
</head>

<?php

	if(!isset($_SESSION['email'])){
		header('location:registration.php');
	}

	$query=mysqli_query($conn, "SELECT * FROM login WHERE email='$_SESSION[email]'") or die(mysqli_error());
	$fetch=mysqli_fetch_array($query);
	$fname=$fetch['fname'];
	$lname=$fetch['lname'];
	$gender=$fetch['gender'];
	$dob=implode("/", array_reverse(explode('-', $fetch['dob'])));
	$email=$fetch['email'];

?>

<body>
	<div id="div10">
	    <div id="div11">
	    	<h1>User Dashboard</h1>
	    	<h6>Name: <?php echo $fname; ?> <?php echo $lname; ?><br>
                Gender: <?php echo $gender; ?><br>
            	Date of Birth: <?php echo $dob; ?><br>
            	Email: <?php echo $email; ?>
            </h6><br><br>
            <button><a href="edit.php" style="text-decoration: none; color: white;">Edit Profile</a></button>
            <br><br>
			<button><a href="logout.php" style="text-decoration: none; color: white;">Logout</a></button>
	    </div>
	</div>
</body>
</html>