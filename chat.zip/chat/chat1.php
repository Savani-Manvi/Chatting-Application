<?php

	include "connection.php";

	session_start();
	
	if(isset($_GET['id'])){
		$id=$_GET['id'];
	}

	$sql=mysqli_query($conn, "SELECT id FROM login WHERE email='$_SESSION[email]'");
	$row=mysqli_fetch_array($sql);

	$sql=mysqli_query($conn, "SELECT * FROM login WHERE id = $id");
	$p=mysqli_fetch_array($sql);

	$query="SELECT * FROM message WHERE (sid, rid) IN (VALUES ('$id', '$row[id]'), ('$row[id]', '$id')) ORDER BY id";
	$mess=$conn->query($query);

?>

<div style="background-color: #f2f2f2; width: 99%; height: 20px; padding-top: 15px; padding-left: 15px; font-size: 20px;">
	<?php echo $p['fname'].' '.$p['lname']; ?>
</div>

<?php

	if($mess->num_rows > 0){
		while($r=$mess->fetch_assoc()){
			$time = date('m/d/Y h:i:s a', strtotime($r['time'])); 
			if($r['sid'] == $id){
				echo "<p align = 'left'>".$r['message']."<span>".$time."</span></p>";
			}
			else{
				echo "<p align = 'right'>".$r['message']."<span>".$time."</span></p>";
			}			
		}
	}

?>