<?php

	include 'connection.php';

?>

<html>
<head>
	<title></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<style type="text/css">
		#div16 {
		    margin: 0 auto;
		    padding: 0px;
		    text-align: center;
		    width: 100%;
		    background-color: #f2f2f2;
		    min-height: 557px;
		}
	    #div16 div {
	        float: left;
	        font-family: helvetica, arial, sans-serif;
	    }
	    table {
  			width: 100%;
  			font-size: 20px;
		}
        tr:nth-child(even) {
        	background-color: #f2f2f2;
        	width: 100%;
        }
        tr:nth-child(odd) {
        	background-color: #f2f2f2;
        	width: 100%;
        }
        td {
        	height: 60px;
        	tab-size: 6;
        }
        #div16 tr td a pre {
        	font-family: sans-serif;
        }
	</style>
</head>
<body>
	    <div id="div16">
	    	<br>

<?php

	if(!isset($_SESSION['email'])){
		header('location:registration.php');
	}

	$query = $conn->prepare("SELECT * FROM login WHERE email != '$_SESSION[email]'");
	$query->execute();
	mysqli_stmt_bind_result($query, $id1, $fname, $lname, $gender, $dob, $email, $password);

?>

<table class="table table-bordered" cellpadding="0" cellspacing="0">

<?php

	while(mysqli_stmt_fetch($query)){

?>

	<tr>
		<td align="left"><a href="chat.php?id=<?php echo $id1;?>" style="text-decoration: none; color: black;"><span style="padding-left: 10px;"><?php echo $fname." ".$lname;?></span></a><hr>
		</td>
	</tr>

<?php

	}

?>

</table>
</div>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" ></script>
</body>
</html>




