<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<style type="text/css">
		body{ 
		    text-align: center;
		    width: 100%;
		    margin: 0 auto;
		    font-family: "lucida grande",tahoma,verdana,arial,sans-serif;
		}
		#header_wrapper {
		    width: 100%;
		    min-width: 90%;
		    background-color: #4C66A4;
		}
		#header {
		    width: 80%;
		    margin: 0px auto;
		    height: 100px;
		}
	    #header li {
	        list-style-type: none;
	        float: left;
	        text-align: left;
	        color: white;
	    }
	    #header #sitename a {
        	margin-top: 25px;
            color: white;
            text-align: left;
            float: left;
            font-size: 40px;
            font-weight: 900;
        }
	    #header form {
	        margin-top: 25px;
	        float: right;
	    }
        #header form li {
            font-size: 13px;
            margin-left: 15px;
        }
        #header form li a {
            color: #A9BCF5;
            text-decoration: none;
        }
        #header form input[type="text"] {
            margin-top: 3px;
            margin-bottom: 3px;
            width: 150px;
            border: 1px solid #08298A;
            height: 25px;
            padding-left: 3px;
        }
        #header form input[type="password"] {
            margin-top: 3px;
            margin-bottom: 3px;
            width: 150px;
            border: 1px solid #08298A;
            height: 25px;
            padding-left: 3px;
        }
        #header form input[type="submit"] {
            height: 25px;
            margin-top: 20px;
            background-color: #4B0082;
            color: white;
            border: 1px solid #08298A;
        }
		#wrapper {
		    margin: 0 auto;
		    padding: 0px;
		    text-align: center;
		    width: 980px;
		}
	    #wrapper div {
	        float: left;
	        font-family: helvetica, arial, sans-serif;
	    }
	    #wrapper #div1 {
	        margin-top: 30px;
	        width: 590px;
	        text-align: left;
	    }
        #wrapper #div1 p {
            font-size: 20px;
            font-family: arial;
            font-weight: bold;
            margin: 0px;
            color: #0e385f;
        }
	    #wrapper #div2 {
	        margin-top: 10px;
	        width: 390px;
	        text-align: left;
	    }
        #wrapper #div2 h1 {
            margin: 0px;
            font-size: 37px;
            color: #2E2E2E;
        }
        #wrapper #div2 li {
            list-style-type: none;
            margin-top: 10px;
        }
        #wrapper #div2 li #firstname {
            width: 49%;
        }
        #wrapper #div2 li #lastname {
            margin-left: 2%;
            width: 49%;
        }
        #wrapper #div2 li input[type="text"] {
            width: 100%;
            height: 40px;
            border-radius: 5px;
            padding-left: 10px;
            font-size: 18px;
            border: 1px solid #BDBDBD;
        }
        #wrapper #div2 li input[type="password"] {
            width: 100%;
            height: 40px;
            border-radius: 5px;
            padding-left: 10px;
            font-size: 18px;
            border: 1px solid #BDBDBD;
        }
        #wrapper #div2 li {
            color: #2E2E2E;
            font-size: 18px;
        }
        #wrapper #div2 li input[type="button"] {
            width: 205px;
            height: 45px;
            text-align: center;
            font-size: 19px;
            margin-top: 10px;
            margin-bottom: 10px;
            font-family: 'Freight Sans Bold', helvetica, arial, sans-serif !important;
            font-weight: bold !important;
            background: linear-gradient(#67ae55, #578843);
            background-color: #69a74e;
            box-shadow: inset 0 1px 1px #a4e388;
            border-color: #3b6e22 #3b6e22 #2c5115;
            border: 1px solid;
            border-radius: 5px;
            color: #fff;
            cursor: pointer;
            display: inline-block;
            position: relative;
            text-shadow: 0 1px 2px rgba(0,0,0,.5);
        }
	</style>
</head>
<body>
	<div class="alert alert-success alert-dismissible" id="success" style="display:none;">
	  <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	</div>

	<div class="alert alert-danger alert-dismissible" id="error" style="display:none;">
	  <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	</div>

	<div id="header_wrapper">
        <div id="header">
        	<lable id="sitename"><a>My Chat</a></lable>
            <form id="login_form" name="form1" method="post">
                <li>Email<br>
                	<input type="text" class="form-control" id="email_log" placeholder="Email" name="email" required="required" />
                </li>
                <li>Password<br>
                	<input type="password" class="form-control" id="password_log" placeholder="Password" name="password" required="required" /><br>
                </li>
                <li><input type="submit" name="save" class="btn btn-primary" value="Sign Up" id="butlogin"></li>
            </form>
        </div>
    </div>

    <div id="wrapper">
        <div id="div1"></div>
        <div id="div2">
        <form id="register_form" name="form1" method="post" class="signup-form">
            <h1>Create an Account</h1>
            <li>First Name<br>
            	<input type="text" class="form-control" id="fname" placeholder="First Name" name="fname" required="required" />
            </li>
            <li>Last Name<br>
            	<input type="text" class="form-control" id="lname" placeholder="Last Name" name="lname" required="required" />
            </li>
            <li>Gender<br>
            	<input type="radio" id="gender" name="gender" value="Male">Male
				<input type="radio" id="gender" name="gender" value="Female">Female
            </li>
            <li>Date of Birth<br>
            	<input type="text" class="form-control" id="dob" placeholder="dd/mm/yyyy" name="dob" required="required" />
            </li>
            <li>Email<br>
            	<input type="text" class="form-control" id="email" placeholder="Email" name="email" required="required" />
            </li>
            <li>Password<br>
            	<input type="password" class="form-control" id="password" placeholder="Password" name="password" required="required" />
            </li>
            <li><input type="button" name="save" class="btn btn-primary" value="Create Account" id="butsave"></li>
        </form>
        </div>
    </div>
<script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js" ></script>
<script>
	$(document).ready(function(){

		$(function() {
            $('#dob').datepicker({
           		dateFormat: "dd/mm/yy"
            });
        });

		$('#butsave').on('click', function(){
			$("#butsave").attr("disabled", "disabled");
			var fname = $('#fname').val();
			var lname = $('#lname').val();
			var gender=$('input[type="radio"]:checked').val();
			var dob=$('#dob').val();
			var email = $('#email').val();
			var password = $('#password').val();
			if(fname!="" && lname!="" && gender!="" && dob!="" && email!="" && password!=""){
				$.ajax({
					url: "save.php",
					type: "POST",
					data: {
						type: 1,
						'fname': fname,
						'lname': lname,
						'gender': gender,
						'dob': dob,
						'email': email,
						'password': password						
					},
					cache: false,
					success: function(dataResult){
						var dataResult = JSON.parse(dataResult);
						if(dataResult.statusCode==200){
							$("#butsave").removeAttr("disabled");
							$('#register_form').find('input:text').val('');
							$("#success").show();
							$('#success').html('');
							alert('Registration successful!'); 						
						}
						else if(dataResult.statusCode==201){
							$("#error").show();
							$('#error').html('');
							alert('Email ID already exists!');
						}
					}
				});
			}
			else{
				alert('Please fill all the field!');
			}
		});

		$('#butlogin').on('click', function(){
			var email = $('#email_log').val();
			var password = $('#password_log').val();
			if(email!="" && password!="" ){
				$.ajax({
					url: "save.php",
					type: "POST",
					data: {
						type:2,
						'email': email,
						'password': password						
					},
					cache: false,
					success: function(dataResult){
						var dataResult = JSON.parse(dataResult);
						if(dataResult.statusCode==200){
							location.href = "profile.php";						
						}
						else if(dataResult.statusCode==201){
							$("#error").show();
							$('#error').html('');
							alert('Invalid EmailId or Password!');
						}	
					}
				});
			}
			else{
				alert('Please fill all the field!');
			}
		});

	});
</script>
</body>
</html>